// Función para calcular el factorial
function calcularFactorial(n) {
    if (n === 0 || n === 1) {
        return 1;
    }
    let factorial = 1;
    for (let i = 2; i <= n; i++) {
        factorial *= i;
    }
    return factorial;
}

// Función para solicitar un número y calcular el factorial
function solicitarNumero() {
    let numero = prompt("Por favor, ingresa un número:");

    // Intentar convertir el valor ingresado a número
    numero = Number(numero);

    // Verificar si el valor es un número
    if (isNaN(numero) || numero < 0) {
        alert("Error: Por favor, ingresa un número válido.");
        solicitarNumero(); // Vuelve a solicitar el número si no es válido
    } else {
        let resultado = calcularFactorial(numero);
        console.log(`El factorial de ${numero} es: ${resultado}`);
        document.getElementById("resultado").textContent = `El factorial de ${numero} es: ${resultado}`;
    }
}

// Llamada a la función principal
solicitarNumero();
